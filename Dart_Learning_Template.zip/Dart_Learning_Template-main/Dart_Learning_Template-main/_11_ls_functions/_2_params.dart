void main() {
  ///
  /// Parameter

  ///
  /// basic params
  /// ****

  int num =add(10, 20);
  print(num);

  /// named params
  ///
  /// ****

  int num2=add2(a: 10, b: 20);
  print(num2);
}


int add2({required int a,required  int b}){
  return a+b;
}

int add(int a, int b){
  return a+b;
}