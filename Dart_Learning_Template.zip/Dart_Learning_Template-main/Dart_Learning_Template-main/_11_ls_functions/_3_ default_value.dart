void main() {
  ///
  /// Default Value
  ///

  /// 1 : with []
  ///
  /// ****

  /// 2 : with {}
  ///
  /// ****
  print(add2(a: 10));

}
int add2({required int a ,int b=40}) {
  return a + b;
}