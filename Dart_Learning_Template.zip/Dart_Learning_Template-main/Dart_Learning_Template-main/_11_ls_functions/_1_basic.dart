void main() {
  ///
  /// Functions
  ///

  /// void func()
  ///
  /// ****

  name();

  /// return func()
  ///
  /// ****

  print(add());
  int num2= add();
  print(num2);
}

void name(){
  print("jame");

}




int add(){
  return 20+20;
}