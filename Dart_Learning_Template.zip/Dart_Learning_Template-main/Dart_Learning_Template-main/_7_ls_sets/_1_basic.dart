void main() {
  ///
  /// Sets
  ///

  /// 1 : Declare a Set
  ///
  /// ****

  //// 2 : Declare a empty Set
  ///
  /// ****

  //// 3 : add value to Set
  ///
  /// ****

  /// 4 : value accessing via for-each
  ///
  /// ****
  ///

  /// 5 : unordered collection
  /// ****
  Set<int> numberSet = {1, 4, 2};
}
