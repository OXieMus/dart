void main() {
  ///
  /// Conditional Expressions
  ///

  bool isLoading=false;
  if(isLoading == true){
    print("Loading");
  }else{
    print("Loaded");
  }

  /// condition ? expr1 : expr2
  ///
  /// ****

  (isLoading) ? print("Loading") : print("Loaded");


}
