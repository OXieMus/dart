void main() {
  ///
  /// const
  ///

  /// const type name = value;
  ///
  /// ****


  const String milk = "jame";
  const double PI = 3.14;

  /// !!!Throw Error

   //const String name;
  //name = "My name";
}
