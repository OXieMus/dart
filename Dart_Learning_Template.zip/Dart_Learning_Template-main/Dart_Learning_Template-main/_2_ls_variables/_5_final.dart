void main() {
  ///
  /// final
  ///
  /// final type name = value
  ///

  final String myName;
  myName= "logan";

  /// final type name
  ///

  /// !!!Throw Error
  //  final String name;
  //  print(name);

  /// !!!Throw Error
  //  final String name;
  // name = "Logan";
  // name = "Greek";
  //  print(name);
}
