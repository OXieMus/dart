void main() {
  /// type name;
  /// ****

  String D="ds";
  print(D);


}
