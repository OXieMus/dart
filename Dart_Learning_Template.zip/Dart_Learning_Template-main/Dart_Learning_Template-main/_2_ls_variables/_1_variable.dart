void main() {
  /// type name = value;
  /// ****

  String ball = "jame";
  int Age = 20;
  double price = 1500;
  print(ball);
}
