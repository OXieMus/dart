void main() {
  ///
  /// var
  ///
  /// type name = value;
  ///
  /// ****

  var berlin= "sia-O";
  var beer = 1550;

  /// type name;
  ///
  /// ****


  var choco;
  choco=" jame";
  choco= 1500;

  print(choco);
}
