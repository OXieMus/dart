void main() {
  ///
  /// Nullable Variable
  ///

  /// 1 : use (?)
  ///
  /// ****

  String? myName;
  print(myName);

  /// 2 : nullable params (function) but not return null
  ///
  /// ****

  /// 3 : nullable params (function) and return null
  ///
  /// ****
}
