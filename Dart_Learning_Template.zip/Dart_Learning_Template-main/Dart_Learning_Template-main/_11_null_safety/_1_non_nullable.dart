void main() {
  ///
  /// Non-nullable variable
  ///

  /// declare variable
  ///
  /// ****
  int r = 4;

  /// late
  ///
  /// ****
  late String name;
  name = "Logan";
}
