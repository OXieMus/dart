void main() {
  ///
  /// Handling null
  ///

  String? myName;
  myName="jame";
  /// 1 : use if
  ///
  /// ****

if(myName!= null){
  print(myName);
}else{
  print("unknown");
}

  /// 2 : Default operator (??)
  ///
  /// ****

  print(myName ?? "unknown");

  /// 3 : Fallback assignment operator (??=)
  ///
  /// ****

  myName ??="unknown";


  /// 4 : Safe navigation operator or Elvis operator (?.)
  ///
  /// ****
  print(myName?.length);
}
