void main() {
  ///
  /// Value accessing
  ///

  /// use the index
  ///
  /// ****
  List<String> animal = ["dog", "cat", "ant"];

  /// 1 : use for loops
  ///
  /// ****

  /// 2 : use for-in
  ///
  /// ****

  for (var x in animal){
    print(x);
  }

  /// 3 : use forEach
  ///
  /// ****

  animal.forEach((element) {
    print(element);
  });
}
