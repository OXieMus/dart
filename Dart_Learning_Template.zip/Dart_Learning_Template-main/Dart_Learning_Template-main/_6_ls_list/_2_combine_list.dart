void main() {
  ///
  /// Combine List
  ///
  /// ****
  List<int> num1 = [1, 2, 3];
  List<int> num2 = [4, 5, 6];


  List numCombine = [...num1,...num2];
  print(numCombine);
}
