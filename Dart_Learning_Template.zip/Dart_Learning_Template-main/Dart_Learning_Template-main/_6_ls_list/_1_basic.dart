void main() {
  ///
  /// List
  ///

  /// Growable List
  ///
  /// 1 : with empty
  /// ****

  /// 2 : with []
  /// ****

  List<String> animal = [];
  animal.add("cat");
  animal.add("bat");
  print(animal);

  /// Fixed-length
  ///
  /// 1 : with filled
  /// ****

  /// 2 : with generate
  /// ****

  /// 3 : order list
  /// ****
  var numbers = [1, 2, 6, 3];
  numbers.sort();
  print(numbers);
}
