void main() {
  ///
  /// string basic
  ///

  /// use single quotes ('')
  ///
  /// ****

  String myName= 'jame';

  /// use double quotes ("")
  ///
  /// ****

  String Name= "jame"
      "ds"
      "sds";

  /// multi-line string (''') or (""")
  ///
  /// ****


  String Text= """ 😘 Food Heaven ! More than 100 different foods in Night Market | Thai Street food

🙏🏻 I appreciate watching our videos and following along. 
      Hopefully you have found at least some of it to be helpful to you. 
      Any feedback is greatly appreciated. 

👍 “Subscribe and Like" is a big inspiration to us !

⭕️ If you want a high-definition video(FHD or 4K), you can select it at the top of the screen.
👀 If you turn on the subtitles, you can see the description of the food.
 """;

  print(Text);
}
