void main() {
  ///
  /// Concatenation
  ///

  /// concatenate string
  ///
  /// ****

  String myName="jame";
  String nickName="logan";

  String  fullname= myName+nickName;
  print(fullname);


  /// concatenate string with variables (all types)
  ///
  /// ****

  int Age= 20;
  String myInfo = fullname +" " + "$Age"+" "+"${Age+100}";
  print(myInfo);
}
