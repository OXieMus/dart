void main() {
  ///
  /// Maps
  ///

  /// 1 : declare Map (Key-Value)
  ///
  /// ****

  /// 2 : adding values to Map
  ///
  /// ****

  /// 3 : accessing values in Map via (forEach)
  ///
  /// ****
  Map<String, String> studentsMap = {'stdId': 'B648909', 'stdName': 'Logan'};
}
