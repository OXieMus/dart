void main() {
  ///
  /// Records
  ///

  /// 1 : declare a record
  ///
  /// ****

  /// 2 : named fields in a record type
  ///
  /// ****
}
