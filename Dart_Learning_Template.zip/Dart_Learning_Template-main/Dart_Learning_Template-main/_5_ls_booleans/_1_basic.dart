void main() {
  ///
  /// Booleans
  ///

  /// basic
  ///
  /// ****

  bool isLoading = true;
  bool isClose =false;

  /// booleans with string
  ///
  /// ****
  String userId = "USER001";
  userId.isEmpty;
  print(userId);
}
