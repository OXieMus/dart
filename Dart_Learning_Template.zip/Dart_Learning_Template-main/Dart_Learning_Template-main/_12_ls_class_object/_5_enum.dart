/// Declare enum
///
/// ****

void main() {
  ///
  /// Enum
  ///

  /// use enum
  ///
  /// ****
}
