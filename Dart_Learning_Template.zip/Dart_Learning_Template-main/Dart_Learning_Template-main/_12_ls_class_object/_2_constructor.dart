/// Declare classes
///
/// ****

void main() {
  ///
  /// Class
  ///

  /// using classes in main
}
