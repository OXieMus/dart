/// Declare classes
/// - Private Variable
/// - Public Variable
/// - getter
/// - setter
/// ****

void main() {
  ///
  /// Class
  ///

  /// using classes in main
}
