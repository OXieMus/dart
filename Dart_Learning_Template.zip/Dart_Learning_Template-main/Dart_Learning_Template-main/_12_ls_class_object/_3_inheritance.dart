/// Declare classes
///
/// ****
class Person {
  final String fullname;
  final int age;
  String? address;

  Person({required this.fullname, required this.age, this.address});
}

/// inherited a class (Student)
///
/// ****

/// inherited a class (Teacher)
///
/// ****

void main() {
  ///
  /// Class
  ///

  /// using classes in main
}
