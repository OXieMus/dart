/// Declare abstract class
///
/// ****

/// Extends an abstract class (Circle)
/// 3.14 * (r * r)
/// ****

/// Extends an abstract class (Rectangle)
/// Length * Width
/// ****

void main() {
  ///
  /// Abstract class
  ///
  /// using classes in main
}
