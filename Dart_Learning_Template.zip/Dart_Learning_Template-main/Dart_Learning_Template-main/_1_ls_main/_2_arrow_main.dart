/// Use an arrow syntax
/// ****