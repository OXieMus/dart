/// main function
/// ****


void main(){
  print("OXIE");
}