void main() {
  ///
  /// Numbers
  ///

  /// int
  ///
  /// ****

  /// double
  ///
  /// ****

  /// num
  ///
  /// ****

  num price = 2;
  price = 25.6;

}
